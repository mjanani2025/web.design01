var i=5;
const j=10;