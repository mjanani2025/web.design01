function sum(x,y){
 document.write(x + y);
}

function minus(x,y){
 return(x-y);
}